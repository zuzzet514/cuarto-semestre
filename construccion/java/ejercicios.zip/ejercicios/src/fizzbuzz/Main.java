package fizzbuzz;

public class Main {
    public static void main(String[] args) {
        ConsoleBasedFizzBuzz c = new ConsoleBasedFizzBuzz();

        c.print(1,100);
    }
}
