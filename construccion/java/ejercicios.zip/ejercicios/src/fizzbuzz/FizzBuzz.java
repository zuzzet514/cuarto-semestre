package fizzbuzz;

public interface FizzBuzz {
    void print(int from, int to);
}
